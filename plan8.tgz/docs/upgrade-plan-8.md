---
type: Guide
title: Upgrade plan 8 — keep the thinking
description: Change plan so that consolidating into the living specs throws nothing away — every task attempt's report and review, every convergence report, every design round's screenshots and every gate draft are committed with the change, and the init-time interviews leave a record.
resource: /docs/upgrade-plan-8.md
status: draft
tags: [sdd, plan, upgrade]
---

# sdd-starter — upgrade plan part 8: keep the thinking

**Executor:** any model. Built and tested before this plan was written; the
complete change ships beside it as `docs/upgrade-plan-8.patch`. Apply, verify
with the walk, delete both files. If a step does not match, stop and report.

**Baseline:** plan 7 applied (branch `007-model-ladder` at `chore(sdd): v7 —
model ladder enforced, verified`). Plan 7 must be applied first; this patch
edits files plan 7 created.

## Why

The living-specs model (part 5) consolidates each change into
`specs/<context>/<capability>.md`, which is right for "what does the system
do now" and wrong as the only record of "why". The change directory was
already archived whole, so intent, proposal, deltas, plan and design
survived. But three kinds of thinking did not:

- Everything the agents wrote under `.sdd/` while building: the implementer
  report per task (concerns, what was hard, what it asked), the task review
  per attempt (what the first attempt got wrong), and the convergence report
  (overwritten by each cycle, then deleted at finish). All gitignored, all
  gone.
- Every draft of a proposal, plan or tasks file that the user sent back. An
  artefact was only committed on approval; the rejected versions were
  overwritten in place and never entered git.
- The init-time interviews. `grill` writes an intent with a verbatim
  question/recommendation/answer record; the product, domain, constitution,
  engineering and design interviews kept only their results, so "why is
  Article VI there" was unrecoverable from the repository.

And the rejected design treatments: `rounds.md` said in words why B lost,
but B's screenshot was in `.sdd/design/` and deleted.

## Decisions (made; do not re-decide)

- **`changes/<id>/record/`, committed, append-only.** `scripts/record.sh`
  copies from `.sdd/` into it: `task T0NN` → `record/tasks/T0NN-report-N.md`
  and `T0NN-review-N.md`, N counting attempts (the fix loop is on the
  record); `converge` → `record/converge-N.md`, one per cycle;
  `design-round N` → `design/rounds/round-N/*.png`, rejected variants
  included. `new-change.sh` seeds the directory; `index.sh` indexes it;
  `sdd-finish` lists it before deleting `.sdd/` and the archive carries it.
  Task briefs and the target preview are not recorded: both are regenerated
  from what is kept.
- **Drafts at every gate.** `scripts/draft.sh <path> [path...]` commits the
  artefact as `docs(<kind>): draft N — <id>` before it is shown; the skills
  call it before each presentation and after each revision (specify, plan,
  tasks, the four init gates; grill at the end of an unresolved session).
  `git log -- changes/<id>/proposal.md` is then the revision history.
- **Interview records** at `docs/interviews/<phase>.md` (type `Interview
  Record`, `open | closed`), from `templates/interview-template.md`, in the
  block shape `grill` uses: question, recommendation, answer in the user's
  words, status, where it landed; plus a `Not asked` list. Written as the
  interview happens by `sdd-init`, `sdd-constitution`, `sdd-engineering`
  and `sdd-design`. The guard treats them as top-of-ladder writes (Fable
  only); `check-specs.sh` warns when a done task has no review on record;
  `AGENTS.md › Never` forbids deleting or rewriting any of it.
- **Not included: exporting the chat transcript itself into the repository.**
  Discussed and dropped from this plan. The record is the agents' written
  account of their work; the session transcript stays where Claude Code
  keeps it.

## Tasks

- [ ] **T801** · On `007-model-ladder` with plan 7 applied and its plan and
  patch removed: `git checkout -b 008-keep-thinking`;
  `git apply --index docs/upgrade-plan-8.patch` → 23 files.
- [ ] **T802** · `bash -n scripts/*.sh scripts/hooks/*.sh`;
  `./scripts/selftest-models.sh` → `✅ 37 checks passed`; OKF sweep clean;
  `grep -c '—\|–' README.md docs/sdd-guide.md` → `0` `0`.
- [ ] **T803** · The walk, in a scratch copy:
  ```bash
  rm -rf /tmp/w8 && cp -r . /tmp/w8 && cd /tmp/w8 && rm -rf .git && git init -q -b main
  git config user.name w && git config user.email w@w && git add -A && git commit -qm base
  ./scripts/new-change.sh keep >/dev/null && ls changes/001-keep | tr '\n' ' '   # → … record …
  mkdir -p .sdd/reports/001-keep .sdd/reviews/001-keep .sdd/design/001-keep/live
  printf -- '---\ntype: Implementation Report\ntitle: r\n---\nSTATUS: DONE\n' > .sdd/reports/001-keep/T011.md
  printf -- '---\ntype: Task Review\ntitle: v\n---\nSPEC: FAIL\n' > .sdd/reviews/001-keep/T011.md
  ./scripts/record.sh changes/001-keep task T011      # → T011-report-1.md, T011-review-1.md
  ./scripts/record.sh changes/001-keep task T011      # → T011-report-2.md, T011-review-2.md
  ./scripts/record.sh changes/001-keep task T099; echo $?   # → error: nothing to record … ; 1
  printf -- '---\ntype: Convergence Report\ntitle: c\n---\nNot converged\n' > .sdd/reports/001-keep/converge.md
  ./scripts/record.sh changes/001-keep converge; ./scripts/record.sh changes/001-keep converge   # → converge-1.md, converge-2.md
  printf PNG > .sdd/design/001-keep/live/a.png; ./scripts/record.sh changes/001-keep design-round 3   # → design/rounds/round-3/a.png
  ./scripts/index.sh | grep -c 'record'               # → 2
  git add -A && git commit -qm seeded
  echo x >> changes/001-keep/proposal.md; ./scripts/draft.sh changes/001-keep/proposal.md   # → draft 1 committed … docs(proposal): draft 1 — 001-keep
  ./scripts/draft.sh changes/001-keep/proposal.md      # → draft: no changes …
  echo y >> changes/001-keep/proposal.md; ./scripts/draft.sh changes/001-keep/proposal.md changes/001-keep/delta   # → draft 2 committed
  git log --oneline -- changes/001-keep/proposal.md | wc -l   # → 3
  sed -i -E 's/<[^>]*>//g' changes/001-keep/proposal.md
  printf '\n### T010 · a.b/REQ-001 · t\n**Status:** done\n**Files** x\n**Steps** y\n**Verify** z\n' >> changes/001-keep/tasks.md
  ./scripts/check-specs.sh 2>/dev/null | grep 'no review'   # → ⚠️  T010 is done but has no review in changes/001-keep/record/tasks/ …
  mkdir -p docs/interviews && sed 's/<phase>/init/g' templates/interview-template.md > docs/interviews/init.md
  ./scripts/fm.py check docs/interviews/init.md      # → ok
  ```
- [ ] **T804** · Commit `feat(sdd): keep the thinking — record/, gate drafts, interview records`;
  `git rm docs/upgrade-plan-8.md docs/upgrade-plan-8.patch`; commit
  `chore(sdd): v8 — record kept, verified`. Report the commits and the walk
  output; the user pushes and opens the pull request.
